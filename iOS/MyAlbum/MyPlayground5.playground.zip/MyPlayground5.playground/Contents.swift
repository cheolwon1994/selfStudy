import UIKit

var evenNumbers:[Int] = [2,4,6,8]
let evenNumbers2:Array<Int> = [2,4,6,8]

evenNumbers.append(10)
evenNumbers+=[12,14,16]
evenNumbers.append(contentsOf:[18,20])

let isEmpty = evenNumbers.isEmpty
let size = evenNumbers.count

//evenNumbers = []
let firstItem = evenNumbers.first

if let firstElement = evenNumbers.first{
    print(firstElement)
} else{
    print("빈 배열")
}

var a = evenNumbers.min()
var b = evenNumbers.max()

var secondItem = evenNumbers[1]
var lastItem = evenNumbers.last


//------>
//부분 배열 반환
let firstThree = evenNumbers[2...6]
//포함 여부(bool)
evenNumbers.contains(3)
evenNumbers.contains(4)

//추가
evenNumbers.insert(0, at: 0)

//삭제
evenNumbers.remove(at: 0)

//전체 삭제
//evenNumbers.removeAll()
//evenNumbers = []

//단일 변환
evenNumbers[0] = -2
evenNumbers

//부분 변환
evenNumbers[0...2] = [-2,0,2]
evenNumbers

//0번과 9번 스왑
evenNumbers.swapAt(0, 9)

//순번, 값 동시에 출력
for (index, num) in evenNumbers.enumerated(){
    print("idx: \(index), value : \(num)")
}

//앞에 3개 원소를 없앤 배열을 반환(실제 배열에는 영향x)
evenNumbers.dropFirst(3)
//뒤 원소 1개 없앤 배열 반환
evenNumbers.dropLast(1)

let firstFour = evenNumbers.prefix(4)
let lastTwo = evenNumbers.suffix(2)
