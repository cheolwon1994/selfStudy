import UIKit

var scoreDic: [String: Int] = ["Jason":80, "Jay":95, "Jake":90]
var scoreDic2: Dictionary<String, Int> = ["Jason":80, "Jay":95, "Jake":90]

scoreDic["Jason"]       //80
scoreDic["Jay"]         //95
scoreDic["Jerry"]       //nil

if let score = scoreDic["Jason"]{
    print(score)
} else{
    print("Score 없음")
}

//scoreDic = [:] ->Empty와 같다
scoreDic.isEmpty
scoreDic.count

//업데이트
scoreDic["Jason"]=95
scoreDic

//추가
scoreDic["Jack"]=100
scoreDic

//제거
scoreDic["Jack"]=nil
scoreDic

//For loop
for(name, score) in scoreDic{
    print("\(name), \(score)")
}

for key in scoreDic.keys{
    print(key)
}

//1. 이름, 직업, 도시에 대해서 본인의 딕셔너리 만들기
var myInfo: [String: String] = ["name": "Mike","job": "Programmer", "location": "Yong-in"]

//2. 도시를 부산으로 업데이트 하기
myInfo["location"]="부산"

//3. 딕셔너리를 받아서 이름과 도시 프린트하는 함수 만들기

func printNameAndCity(dic: [String:String]){
    if let name = dic["name"], let city = dic["location"]{
        print(name, city)
    } else{
        print("-->Cannot find")
    }
}
printNameAndCity(dic: myInfo)
