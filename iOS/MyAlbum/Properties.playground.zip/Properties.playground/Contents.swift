import UIKit

struct Person{
    //Stored Property
    var firstName: String{
//        willSet{
//            print("willSet: \(firstName) --> \(newValue)")
//        }
        didSet{
            print("didSet: \(oldValue)-->\(firstName)")
        }
    }
    var lastName: String
    
    lazy var isPopular: Bool = {
        if fullName == "Jay Park" {
            return true
        } else{
            return false
        }
    }()
    
//    var fullName: String{
//        return "\(firstName) \(lastName)"
//    }
    var fullName: String{
        //불러오기
        get{
            return "\(firstName) \(lastName)"
        }
        //설정
        set{
            if let firstName = newValue.components(separatedBy: " ").first{
                self.firstName=firstName
            }
            if let lastName = newValue.components(separatedBy: " ").last{
                self.lastName=lastName
            }
        }
    }
    
    //type Property
    static let isAlien: Bool = false
}

var person = Person(firstName: "Jason", lastName: "Lee")

person.firstName            //Jason
person.lastName             //Lee

person.firstName = "Jim"
person.lastName = "Kim"

person.firstName            //Jim
person.lastName             //Kim

person.fullName             //Jim Kim
person.fullName = "Jay Park"

person.firstName            //Jay
person.lastName             //Park


Person.isAlien              //false

person.isPopular            //true
