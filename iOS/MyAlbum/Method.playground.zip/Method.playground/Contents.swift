import UIKit

struct Lecture{
    var title: String
    var maxStudents: Int = 10
    var numOfRegistered: Int = 0
    
    func remainSeats() -> Int{
        let remainSeats = lec.maxStudents - lec.numOfRegistered
        return remainSeats
    }
    
    mutating func register() -> Void{       //stored property를 변경시키는 경우 mutating 사용
        //등록된 학생수 증가시키기
        numOfRegistered+=1;
    }
    //type property
    static let target: String = "Anybody who wants to learn"
    
    static func 소속이름() ->String{
        return "어딘가"
    }
}

var lec = Lecture(title: "iOS Basic")
lec.remainSeats()       //10

lec.register()
lec.register()
lec.register()
lec.register()
lec.remainSeats()       //6

Lecture.target          //"Anybody who wants to learn"
Lecture.소속이름()          //"어딘가"


struct Math {
    static func abs(value: Int) -> Int{
        if value > 0{
            return value
        }
        else {
            return -value
        }
    }
}
Math.abs(value: -20)

//Math 확장
extension Math{
    static func square(value: Int) -> Int{
        return value * value
    }
    
    static func half(value: Int) -> Int{
        return value/2
    }
}

Math.square(value: 5)           //25
Math.half(value: 20)            //10

var value: Int = 3

extension Int {
    func square() -> Int{
        return self * self
    }
    func half() -> Int{
        return self/2
    }
}
value.square()          //9
value.half()            //1
