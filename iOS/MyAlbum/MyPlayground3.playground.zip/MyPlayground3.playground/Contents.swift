import UIKit

//1. 성, 이름을 받아서 fullname을 출력하는 함수 만들기
//func fullName(name: String, lastName: String){
//    print("\(lastName) \(name)")
//
//}
//fullName(name: "철원", lastName: "최")
//
//2. 1번에서 만든 함수인데, 파라미터 이름을 제거하고 fullname출력하는 함수 만들기
//func fullName2(_ name: String,_ lastName: String){
//    print("\(lastName) \(name)")
//
//}
//fullName2("철원", "최")
//3. 성, 이름을 받아서 fullname return하는 함수 만들기

//func fullName3(firstName: String, lastName: String) ->String{
//    return "\(lastName) \(firstName)"
//}
//let fullname = fullName3(firstName: "Michael", lastName: "Choi")
//
//
//func printTotalPrice(price:Double, count: Double){
//    print("Total Price: \(price*count)")
//}
//printTotalPrice(price: 1.5, count: 3)
//
//
////In-Out parameter
//var value=3
//func incrementAndPrint(_ value: inout Int){
//    value+=1
//    print(value)
//}
//incrementAndPrint(&value)

//----Function as a param
func add(_ a: Int, _ b: Int)->Int{
    return a+b
}
func subtract(_ a: Int, _ b: Int)->Int{
    return a-b
}

var function = add
print(function(4,2))        //6
function = subtract
print(function(4,2))        //2

func printResult(_ function:(Int, Int) -> Int, _ a: Int, _ b: Int){
    let result = function(a,b)
    print(result)
}

printResult(add, 10, 5)             //15
printResult(subtract, 10, 5)        //5


