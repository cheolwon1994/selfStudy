import UIKit

var carName: String? = nil
carName = nil
carName = "땡크"


//아주 간단한 예제
//여러분이 최애하는 영화배우의 이름을 담는 변수를 작성해주세요 (타입 String?)
//let num = Int("10") -> 타입은 뭘까요

var favoriteActor: String? = "이병헌"
let num = Int("10")

//고급 기능 4가지

//Forced unwrapping. > 억지로 박스를 까보기
//Optional binding(if let)  > 부드럽게 박스를 까보자 1
//Optional binding(guard)   > 부드럽게 박스를 까보자 2
//Nil coalescing    > 박스를 까봤더니, 값이 없으면 디폴트 값을 줘보자

//carName = nil
//print(carName!)
if let unwrappedCarName = carName{
    print(unwrappedCarName)
} else{
  print("Car name 없다")
}


func printParsedInt(from: String){
    if let parsedInt = Int(from){
        print(parsedInt)
    } else{
        print("Int로 컨버팅 불가")
    }
}


func printParsedInt2(from: String){
    guard let parsedInt = Int(from) else {
        print("Int로 컨버팅 불가")
        return
    }
    print(parsedInt)
}


printParsedInt2(from: "100")         //if문 출력
printParsedInt2(from: "100.1")       //else문 출력

carName=nil
let myCarName: String = carName ?? "모델 S"

//---도전과제
//1. 최애 음식이름을 담는 변수를 작성(String optional)
let favoriteDish: String? = nil
//2. 옵셔널 바인딩을 이용해서 값을 확인해보기
if let unwrappedDish = favoriteDish{
    print(unwrappedDish)
} else{
    print("No favorite Dish")
}
//3. 닉네임을 받아서 출력하는 함수 만들기, 조건 입력 파라미터는 String?

func printNickname(name: String?){
    guard let nickName = name else{
        print("No nickname")
        return
    }
    print(nickName)
}
printNickname(name: nil)

