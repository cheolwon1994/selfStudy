import UIKit

//도전 과제
//1. 강의 이름, 강사 이름, 학생수를 가지는 Struct 만들기(Lecture)
//2. 강의 어레이어와 강사이름을 받아서, 해당 강사의 강의 이름을 출력하는 함수 만들기
//3. 강의 3개 만들고 강사 이름으로 강의 찾기


//CustomStringConvertible
struct Lecture: CustomStringConvertible{
    var description: String{
        return "Title: \(lectureName), Teacher: \(teacher)"
    }
    
    var lectureName: String
    var teacher: String
    var studentNum: Int
    
    init(lectureName: String, teacher: String, studentNum: Int){
        self.lectureName = lectureName
        self.teacher = teacher
        self.studentNum = studentNum
    }
}

func printLectureName(lectures: [Lecture], name: String){
    for lec in lectures{
        let tname = lec.teacher
        let lname = lec.lectureName
        if tname == name {
            print(lname)
        }
    }
}

let l1 = Lecture(lectureName: "PE",teacher: "Ashe",studentNum:20)
let l2 = Lecture(lectureName: "Science",teacher: "Josh",studentNum:15)
let l3 = Lecture(lectureName: "Math",teacher: "Amily",studentNum:25)

let lectures = [l1,l2,l3]
printLectureName(lectures: lectures, name: "Amily")

print(l1)
