import UIKit
import Foundation
//var i = 0
////while i<10 {
////    print(i)
////    i+=1
////}
//
//print("------While")
//i=10
//while i<10 {
//    print(i)
////    if i==5 {
////        break
////    }
//    i+=1
//}
//print("------Repeat - While")
//i=10
//repeat {
//    print(i)
//    i+=1
//} while i<10

//
//let onClosedRange = 0...10
//let onHalfRange = 0..<10
//
//var sum = 0
//for i in onClosedRange{
//    print("----->\(i)")
//    sum+=i
//}
//print("----->sum: \(sum)")
//var j=0, tot=0
//for j in onHalfRange{
//    print("----->\(j)")
//    tot+=j
//}
//print("---->tot: \(tot)")
//
//for _ in onClosedRange{
//    print("Hi")
//}
//var sinValue: CGFloat=0
//for i in onClosedRange{
//    sinValue = sin(CGFloat.pi/4*CGFloat(i))
//}
//
//
//for i in onClosedRange{
//    if i%2==0{
//        print("-----> 짝수: \(i)")
//    }
//}
//
//for i in onClosedRange where i%2==0{
//    print("-----> 짝수: \(i)")
//}
let num=10
switch num {
case 0..<10:
    print("---->0~9입니다")
case 10..<20:
    print("---->10~20입니다")
default:
    print("---->나머지 입니다")
}
let pet = "개"
switch pet{
case "dog", "개":
        print("---->개입니다")
    default:
        print("---->나머지")
}

let coordinate = (x:10, y:10)
switch coordinate{
case(0,0):
    print("원점")
case(let x,0):
    print("x축이네요, x : \(x)")
case(0,let y):
    print("y축이네요, y : \(y)")
case(let x, let y) where y==x:
    print("x랑 y가 같음, x: \(x), y: \(y)")
case(let x, let y):
    print("좌표 어딘가, x: \(x), y: \(y)")
}
