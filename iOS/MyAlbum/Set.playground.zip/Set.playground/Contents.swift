import UIKit

var someArray: Array<Int> = [1,2,3,1]
var someSet: Set<Int> = [1,2,3,1,2]

someSet.isEmpty
someSet.count
someSet.contains(1)

someSet.insert(5)
someSet

someSet.remove(1)
someSet
