import UIKit
/*
 {(param) -> return type in
    statement
    ...
 */

//#1. 초 Simple Closure
let choSimpleClosure = {
    
}
choSimpleClosure()
//#2. 코드블록을 구현한 Closure
let choSimpleClosure2 = {
    print("Hello, Closure")
}
choSimpleClosure2()

//#3. 인풋 파라미터를 받는 Closure
let choSimpleClosure3: (String) -> Void = { name in
    print("Hello, Closure. My name is \(name)")
}
choSimpleClosure3("Mike")


//#4. 값을 리턴하는 Closure
let choSimpleClosure4: (String) -> String = { name in
    let message = "iOS Developer \(name)"
    return message
}
let result = choSimpleClosure4("Mike")
print(result)

//#5. Closure를 파라미터로 받는 함수 구현
func someSimpleFunction(choSimpleClosure: () -> Void){
    print("호출")
    choSimpleClosure()
}
someSimpleFunction(choSimpleClosure:  {
    print("Hello Corona")
})

//#6. Trailing Closure
func someSimpleFunction2(message: String, choSimpleClosure2: () -> Void){
    print("함수에서 호출됨. 메세지는 : \(message)")
    choSimpleClosure2()
}
someSimpleFunction2(message: "메로나" , choSimpleClosure2: {
    print("Hello Corona from Closure")
})

