import UIKit

func printName(){
    print("--->My name is Jason")
}

printName()

//param 1개
//숫자를 받고, 10을 곱해서 출력한다

func printMul10(value: Int){
    print("\(value)*10 = \(value*10)")
}
printMul10(value : 5)


//param 2개
//물건값과 개수를 받아서 전체 금액을 출력하는 함수
//func printTotalPrice(price: Int, count: Int){
//    print("Total Price: \(price*count)")
//}
//printTotalPrice(price: 1500, count: 5)

//
//func printTotalPrice(_ price: Int,_ count: Int){
//    print("Total Price: \(price*count)")
//}
//
//printTotalPrice(1500,5)


//func printTotalPrice(가격 price: Int,개수 count: Int){
//    print("Total Price: \(price*count)")
//}

//printTotalPrice(가격: 1500,개수: 5)


func printTotalPrice(가격 price: Int = 1500,개수 count: Int){
    print("Total Price: \(price*count)")
}


printTotalPrice(개수: 10)


func totalPrice(price: Int, count: Int) -> Int{
    let totalPrice = price * count
    return totalPrice
}
let calculatedPrice = totalPrice(price: 10000, count: 77)
calculatedPrice
